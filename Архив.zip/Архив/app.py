# app.py
import streamlit as st
from config.settings import settings
from src.core.neo4j_client import neo4j_client
from ui.views.search_view import render_search_view
from ui.views.import_view import render_import_view
from ui.views.dashboard_view import render_dashboard_view

# app.py (Добавьте это на самый верх файла)
import warnings
import logging

# 1. Глушим стандартные предупреждения Python (включая UserWarning)
warnings.filterwarnings("ignore", category=UserWarning)

# 2. Глушим официальный логгер Hugging Face transformers
try:
    from transformers import logging as transformers_logging
    transformers_logging.set_verbosity_error()
except ImportError:
    pass

# 3. Настраиваем стандартное логирование на уровень ERROR для ИИ-моделей
logging.getLogger("transformers").setLevel(logging.ERROR)
logging.getLogger("torch").setLevel(logging.ERROR)
# Инициализируем ограничения в Neo4j при первом запуске
try:
    neo4j_client.init_constraints()
except Exception as e:
    pass  # Если база недоступна на этапе инициализации, обработаем это в UI

st.set_page_config(
    page_title="R&D Knowledge Graph - Норникель",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Боковое меню
st.sidebar.markdown(
    """
    <div style="background-color:#0f172a; padding: 15px; border-radius: 10px; margin-bottom: 20px; border: 1px solid #1e293b;">
        <h2 style="color:#38bdf8; font-family:sans-serif; margin:0; font-size:22px; letter-spacing: 1px;">НОРНИКЕЛЬ</h2>
        <p style="color:#94a3b8; font-family:sans-serif; margin:0; font-size:14px; font-weight:bold;">R&D КАРТА ЗНАНИЙ</p>
    </div>
    """, 
    unsafe_allow_html=True
)

# Эмуляция ролевой модели доступа (RBAC) соответствии с ИБ
st.sidebar.subheader("🔒 Авторизация (Роль)")
user_role = st.sidebar.selectbox(
    "Выберите вашу учетную запись:",
    ["Исследователь R&D (Public)", "Аналитик (Internal)", "Главный инженер (Confidential)"]
)

st.sidebar.markdown("---")

# Навигация по вкладкам
st.sidebar.subheader("🧭 Навигация")
menu_selection = st.sidebar.radio(
    "Перейти на страницу:",
    ["Поиск и GraphRAG", "Импорт Документов", "Аналитика и Дашборды"]
)

# Маршрутизация
if menu_selection == "Поиск и GraphRAG":
    render_search_view(user_role)
elif menu_selection == "Импорт Документов":
    render_import_view()
elif menu_selection == "Аналитика и Дашборды":
    render_dashboard_view()

# Закрытие сессий при остановке (Streamlit вызывает скрипт заново при каждом действии)
# Драйвер Neo4j управляет собственным пулом соединений, закрывать его при каждом рендере не требуется.