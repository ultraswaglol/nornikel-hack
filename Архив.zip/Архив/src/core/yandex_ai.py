# src/core/yandex_ai.py
import os
import time
import random
from typing import List
from openai import OpenAI
from config.settings import settings

class YandexAIClient:
    def __init__(self):
        self.mock_mode = settings.mock_mode
        self.folder_id = settings.yandex_folder_id
        
        if not self.mock_mode:
            # Настройка OpenAI-совместимого клиента под требования Yandex AI Studio v1
            self.client = OpenAI(
                api_key=settings.yandex_ai_studio_api_key,
                base_url="https://ai.api.cloud.yandex.net/v1",
                project=self.folder_id  # Передаем FOLDER_ID как project
            )

    def get_text_completion(self, model_name: str, messages: List[dict], temperature: float = 0.1, json_mode: bool = False) -> str:
        """Генерация текста с автоматическим маппингом и экспоненциальным откатом при ошибках 429"""
        if self.mock_mode:
            user_text = messages[-1]["content"].lower()
            if "cypher" in messages[0]["content"].lower():
                if "обессоливани" in user_text:
                    return "MATCH (p:Process {id: 'PROC_DESALINATION'})-[:operates_at_condition]->(pr:Property) RETURN p.name, pr.name, pr.value, pr.unit"
                elif "электроэкстракц" in user_text or "flow rate" in user_text:
                    return "MATCH (p:Process {id: 'PROC_ELECTROWINNING'})-[:operates_at_condition]->(pr:Property) RETURN p.name, pr.name, pr.value, pr.unit"
                return "MATCH (n)-[r]->(m) RETURN n.name, type(r), m.name LIMIT 10"
                
            if "эксперт-технолог" in messages[0]["content"].lower():
                if "обессоливани" in user_text:
                    return """На основе анализа R&D-отчетов компании, для исходной воды с содержанием сульфатов (250 мг/л) рекомендуется метод **обратного осмоса (reverse osmosis)**. 
                    Согласно экспериментальным данным из отчета *'Water Desalination Methods for Enrichment Plant'*, этот метод позволяет снизить сухой остаток до **950 мг/дм³**, что полностью удовлетворяет убедительному показателю в 1000 мг/дм³. Процесс протекает при рабочем давлении до 1.5 МПа."""
                elif "электроэкстракц" in user_text:
                    return """В базе знаний зафиксировано противоречие относительно оптимальной скорости циркуляции католита при электроэкстракции никеля:
                    1. Отечественная практика (*Отчет лаборатории гидрометаллургии Норникеля*): рекомендует скорость **1.5 м/с** для предотвращения загрязнения катодов.
                    2. Зарубежная практика (*Исследование Outokumpu Technology*): рекомендует поддерживать скорость на уровне **3.5 м/с** во избежание истощения прикатолидного слоя.
                    Скорости ниже 2.0 м/с по зарубежным источникам ведут к росту дендритов, что расходится с отечественными рекомендациями."""
            return "Имитационный режим: Ответ сгенерирован локально. Система готова к подключению к Yandex AI Studio."

        # Реальный режим работы
        mapped_model = model_name
        if model_name in ["alice-ai-flash", "alice-ai-llm-flash"]:
            mapped_model = "yandexgpt-lite"
        elif model_name in ["alice-ai", "alice-ai-llm"]:
            mapped_model = "yandexgpt"

        model_uri = f"gpt://{self.folder_id}/{mapped_model}/latest"
        kwargs = {
            "model": model_uri,
            "messages": messages,
            "temperature": temperature
        }
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}
            
        max_retries = 5
        base_delay = 1.0  # Базовая задержка в 1 секунду
        
        for attempt in range(max_retries):
            try:
                response = self.client.chat.completions.create(**kwargs)
                return response.choices[0].message.content.strip()
            except Exception as e:
                # Если поймали лимит запросов (429) или ошибку перегрузки сервера
                if "429" in str(e) or "limit exceed" in str(e).lower() or "quota" in str(e).lower():
                    # Экспоненциальный откат с рандомизацией (jitter) во избежание синхронных повторов
                    delay = base_delay * (2 ** attempt) + random.uniform(0.1, 0.5)
                    print(f"⚠️ [API 429]: Превышен лимит одновременных запросов. Повторная попытка {attempt+1}/{max_retries} через {delay:.2f} сек...")
                    time.sleep(delay)
                else:
                    # Если ошибка другая (например, неверный ключ или URL), выбрасываем её сразу
                    raise e
                    
        raise Exception("Превышены все попытки обращения к Yandex GPT API из-за лимитов одновременных сессий.")

    def get_embedding(self, text: str, is_query: bool = False) -> List[float]:
        """Генерация эмбеддинга с защитой от ошибок 429"""
        if self.mock_mode:
            return [0.0] * 256
            
        model_type = "text-search-query" if is_query else "text-search-doc"
        model_uri = f"emb://{self.folder_id}/{model_type}/latest"
        
        max_retries = 5
        base_delay = 1.0
        
        for attempt in range(max_retries):
            try:
                response = self.client.embeddings.create(
                    input=[text],
                    model=model_uri,
                    encoding_format="float"
                )
                return response.data[0].embedding
            except Exception as e:
                if "429" in str(e) or "limit" in str(e).lower() or "quota" in str(e).lower():
                    delay = base_delay * (2 ** attempt) + random.uniform(0.1, 0.5)
                    print(f"⚠️ [API 429]: Превышен лимит эмбеддингов. Повторная попытка {attempt+1}/{max_retries} через {delay:.2f} сек...")
                    time.sleep(delay)
                else:
                    raise e
                    
        raise Exception("Превышены все попытки получения эмбеддингов из-за лимитов одновременных сессий.")

yandex_ai = YandexAIClient()